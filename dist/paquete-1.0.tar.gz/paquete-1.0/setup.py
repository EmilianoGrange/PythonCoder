from setuptools import setup

setup(
    name = "paquete",
    version = "1.0",
    description = "Primer paquete redistribuible",
    author = "Emiliano Grange",
    author_email = "tool69@gmail.com",

    packages = ["paquete"]
)